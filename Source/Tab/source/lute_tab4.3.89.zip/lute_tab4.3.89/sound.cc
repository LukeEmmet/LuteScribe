#include <stdio.h>
#ifndef __APPLE__
// #include <malloc.h>
#endif
#include "tab.h"
#include "sound.h"
#include <math.h>

sound::sound()
{
  //  printf("sound constructor\n");
}

sound::~sound()
{
  //  printf("sound destructor\n");
}
