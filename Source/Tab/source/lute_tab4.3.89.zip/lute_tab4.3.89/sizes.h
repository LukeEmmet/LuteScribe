/*
 *
 * to go with sizes.c
 * 
 */

extern double st_text;
extern double m_space;
extern char flag_to_staff[];
extern int st_italian;
extern char italian_offset[];
extern char em[];
extern char interspace[];
extern double staff_len;
extern double o_staff_len;
extern char staff_height[];
extern double text_sp;
extern char mus_space[];
extern int n_measures;
extern char thick_bar[];
extern char baselinespace[]; 
extern char grid_indent[];
extern char flag_indent[];
extern char i_flag_indent[];

